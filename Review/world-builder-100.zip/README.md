# World Builder 100

100 native 32x32 terrain tiles across ten biome families, plus 32 transparent object sprites:
16 directional vehicles at 128x128, 8 trees at 64x64, 4 mountain landmarks and 4 cavern entrances at 64x64.

All assets use 32 pixels per Unity unit. Tile pivots are centered; object pivots are specified per asset
in manifest.json. Import with Sprite(2D/UI), Point filtering, no compression, no mipmaps, Clamp wrapping.
Vehicles are static down/left/right/up views, not animated motion clips. The fantasy propeller plane
is an optional original extension. Transparent frame bounds are not collision footprints.

Terrain sets use NW/N/NE, W/center/E, SW/S/SE outer pieces plus an alternate center. They do not
include a complete inner-corner/autotile matrix or every cross-biome transition. Visible joins and
material repetition still require visual cleanup. Test actual placement before building finished maps.

Generated with the built-in ImageGen tool using online FFII references and approved project art.
Online reference images are not packaged. Source prompts and provenance remain in the project:
Docs/WorldObjectSources.md, Docs/BiomesNaturalSources.md, Docs/BiomesExtremeSources.md,
References/WorldBuilder100/README.md and ArtSource/RemasterExpansion source folders.

PNG files are authoritative. manifest.json gives file hashes, dimensions, PPU, pivots and source paths.
The 320x320 packed atlas contains the same 100 tiles; atlas-coordinates.json maps its cells to IDs.
It is a convenience copy, not another 100 distinct assets. construction-guide.md explains placement.
These are exported review assets, not a playable game or validated Unity scene.