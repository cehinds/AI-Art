Literal combat-concept visible fragments

Place every RGBA PNG at manifest offset; masks partition all source pixels. Alpha is binary source ownership, preserving original edge RGB. Fragments contain no invented hidden pixels. Text remains raster, with editable transcription in the manifest. These are source-visible fragments, not clean independent sprites. Procedural variants and their normalized source samples are separately labeled derived assets.
