# Portable concept room generator

Requires Python 3.10+, Pillow, and Node.js 18+ on PATH.
From this unpacked directory run:

    python generate.py --engine concept-room-engine.js --recipe recipe.json --asset-root assets --out output --seed 9 123

Outputs are room-SEED.png and room-SEED.json plus the executable recipe copy.
The shared JavaScript compiler validates the recipe and catalog before placement.
No original reference, repository checkout, canonical fragment assets, or network is required.
Assets include visible-source assemblies and explicitly synthesized modules; consult catalog provenance.
Literal source fragments are supplied separately in combat-concept-components.zip.
